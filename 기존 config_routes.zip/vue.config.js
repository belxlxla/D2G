const { defineConfig } = require('@vue/cli-service');

module.exports = defineConfig({
  transpileDependencies: true,
  devServer: {
    allowedHosts: 'all',
    port: 8080,
    // 웹소켓 관련 설정
    proxy: {
      '/api': {
        target: 'http://localhost:3000',
        changeOrigin: true,
      },
      '/socket.io': {
        target: 'https://www.daeng2go.com',
        ws: true,
        changeOrigin: true,
      },
    },
  },
});
